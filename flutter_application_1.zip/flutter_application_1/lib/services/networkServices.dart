import 'package:flutter_application_1/models/productClass.dart';
import 'package:http/http.dart' as http;

class Networkservices {
  String url = 'https://fakestoreapi.com/products';

   getProduct() async {
    final response = await http.get(Uri.parse(url));
    if (response.statusCode == 200) {
      print('success');

      return productsFromJson(response.body);
    } else {
      print("error occured");
    }
  }
  postProducts(){
    
  }


}

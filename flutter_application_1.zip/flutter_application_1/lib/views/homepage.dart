import 'package:flutter/material.dart';
import 'package:flutter_application_1/providers/productProvider.dart';
import 'package:flutter_application_1/widgets/ProductCard.dart';
import 'package:provider/provider.dart';

class Homepage extends StatefulWidget {
  const Homepage({Key? key});

  @override
  State<Homepage> createState() => _HomepageState();
}

class _HomepageState extends State<Homepage> {
  @override
  void initState() {
    Provider.of<ProductProvider>(context, listen: false)
                  .getProducts();
    // TODO: implement initState
    super.initState();
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(
        children: [
          Row(
            children: [
              Text(
                "Products",
                style: TextStyle(fontSize: 40),
              ),
            ],
          ),
         
          Expanded(
            child: Consumer<ProductProvider>(
              builder: (context, provider, child) {
                // Check if data is available before accessing it
                if (provider.productList.isEmpty) {
                  return Center(
                      child: provider.isLoading
                          ? CircularProgressIndicator()
                          : Text('No data available'));
                }
                return GridView.builder(
                  gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                    crossAxisCount: 3, // number of items in each row
                    mainAxisSpacing: 15.0, // spacing between rows
                    crossAxisSpacing: 8.0, // spacing between columns
                  ),
                  itemCount: provider.productList.length,
                  itemBuilder: (context, index) {
                    final product = provider.productList[index];
                    return ProductCard(
                      product: product,
                    );
                  },
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}

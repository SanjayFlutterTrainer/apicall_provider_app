import 'package:flutter/material.dart';
import 'package:flutter_application_1/models/productClass.dart';
import 'package:flutter_application_1/views/productDetails.dart';

class ProductCard extends StatelessWidget {
  Products? product;
  ProductCard({super.key,this.product });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(onTap: (){
      Navigator.push(context, MaterialPageRoute(builder: (context) {
        return ProductDetails(product: product,);
      },));
    },
      child: Container(margin: EdgeInsets.all(15),padding: EdgeInsets.all(10),
        decoration: BoxDecoration(borderRadius: BorderRadius.circular(25),border: Border.all(color: Colors.black)),
        child: Column(mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Image.network(
              product!.image,
              height: 200,
              width: 180,
            ),
            Column(
              children: [
                Text(product!.title,style: TextStyle(fontSize: 30,fontWeight: FontWeight.bold),),
                SizedBox(child: Text(product!.description, overflow: TextOverflow.ellipsis,)),
              ],
            )
          ],
        ),
      ),
    );
  }
}

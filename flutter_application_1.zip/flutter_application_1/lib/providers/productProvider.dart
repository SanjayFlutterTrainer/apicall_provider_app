import 'package:flutter/material.dart';
import 'package:flutter_application_1/models/productClass.dart';
import 'package:flutter_application_1/services/networkServices.dart';

class ProductProvider extends ChangeNotifier {
  List<Products> productList = [];
  bool isLoading = false;
  Networkservices productServices = Networkservices();

  Future<void> getProducts() async {
    isLoading = true;
    notifyListeners();
    try {
      productList = await productServices.getProduct();
      isLoading = false;
      notifyListeners();
    } catch (e) {
      print('Error fetching products: $e');
      // Handle error, e.g., show a snackbar or retry logic
    }
  }
}

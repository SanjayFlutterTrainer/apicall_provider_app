import 'dart:io';

import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';

class ImagePick extends StatefulWidget {
  const ImagePick({super.key});

  @override
  State<ImagePick> createState() => _ImagePickState();
}

class _ImagePickState extends State<ImagePick> {
  final ImagePicker picker = ImagePicker();
  String? pickedImage;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        body: Center(
            child: Column(
      children: [
        ElevatedButton(
            onPressed: () async {
              final XFile? image =
                  await picker.pickImage(source: ImageSource.camera);
              setState(() {
                pickedImage = image!.path;
              });
            },
            child: Text("get image  ")),
        pickedImage == null
            ? CircularProgressIndicator()
            : Image.file(File(pickedImage!))
      ],
    )));
  }
}
